let currentFolder = ''; // Текущая папка
let currentPath = []; // Путь к текущей папке

// Функция для выхода из системы
function logout() {
    fetch('/logout', { method: 'POST' })
        .then(response => response.ok ? window.location.href = '/' : alert('Ошибка выхода'))
        .catch(console.error);
}

function showUserInfo() {
    // Переход на страницу /info
    window.location.href = "/info";
}
// Отображение/скрытие трея
function toggleUserTray() {
    const tray = document.getElementById("userTray");
    tray.classList.toggle("hidden");
}

function uploadFiles() {
    const files = document.getElementById('fileInput').files;
    if (!files.length) return alert("Пожалуйста, выберите файлы для загрузки.");
    
    uploadHandler(files, '/upload');
    
}

function uploadFolder() {
    const files = document.getElementById('folderInput').files;
    if (!files.length) return alert("Пожалуйста, выберите папку для загрузки.");
    
    uploadHandler(files, '/upload');
    
}

function uploadHandler(files, url) {
    const progressContainer = document.getElementById('upload-progress-container');
    const progressBar = document.getElementById('upload-progress-bar');
    const uploadPercentage = document.getElementById('upload-percentage');
    const uploadFileName = document.getElementById('upload-file-name');
    progressContainer.style.display = 'flex';
    let currentFileIndex = 0;

    function uploadFile(file) {
        const xhr = new XMLHttpRequest();
        const formData = new FormData();
        formData.append('files', file, encodeURIComponent(file.webkitRelativePath || file.name));

        xhr.open('POST', `${url}?folder=${encodeURIComponent(currentFolder)}`, true);

        xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) {
                const percentComplete = (e.loaded / e.total) * 100;
                progressBar.style.width = percentComplete + '%';
                uploadPercentage.textContent = Math.round(percentComplete) + '%';
            }
        };

        xhr.onload = () => {
            if (xhr.status === 200) {
                currentFileIndex++;
                loadFilesInCurrentFolder();
                currentFileIndex < files.length ? uploadFile(files[currentFileIndex]) : resetProgress();
            } else {
                resetProgress();
                console.error('Ошибка при загрузке файла.');
            }
        };

        xhr.onerror = resetProgress;
        xhr.send(formData);
        uploadFileName.textContent = `Файл: ${file.name}`;
    }

    function resetProgress() {
        setTimeout(() => {
            progressBar.style.width = '0%';
            uploadPercentage.textContent = '0%';
            uploadFileName.textContent = 'Файл: ';
            progressContainer.style.display = 'none';
        }, 1000);
    }

    uploadFile(files[currentFileIndex]);
}


// Функция для создания новой папки
function createFolder() {
    const folderName = prompt("Введите имя новой папки:");
    if (!folderName) return;

    fetch('/create-folder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ folderName: folderName, currentPath: currentFolder })
    })
    .then(() => loadFilesInCurrentFolder()) // Обновляем список файлов после создания папки
    .catch(console.error);
}

// Открытие папки
function openFolder(folderName) {
    const newPath = [...currentPath, folderName].join('/'); // Формируем новый путь

    if (currentFolder === newPath) {
        return;
    }

    fetch(`/check-folder?folder=${encodeURIComponent(newPath)}`)
        .then(response => {
            if (response.ok) {
                currentPath.push(folderName); // Добавляем папку в путь
                currentFolder = newPath;
                document.getElementById('folderName').textContent = `./${currentFolder}`;
                loadFilesInCurrentFolder();
            } else {
                alert('Папка не найдена. Проверьте имя или путь.');
            }
        })
        .catch(error => {
            console.error('Ошибка при проверке папки:', error);
            alert('Произошла ошибка при проверке папки. Пожалуйста, попробуйте позже.');
        });
}

// Функция для перехода назад
function goBack() {
    if (currentPath.length) {
        currentPath.pop();
        currentFolder = currentPath.join('/');
        document.getElementById('folderName').textContent = `./${currentFolder}`;
        loadFilesInCurrentFolder(); // Обновляем список файлов при переходе назад
    }
}

function loadFilesInCurrentFolder() {
    const folderList = document.getElementById('folderList');
    const fileArea = document.getElementById('fileArea');
    
    folderList.innerHTML = '';
    fileArea.innerHTML = '';

    fetch(`/files?folder=${encodeURIComponent(currentFolder)}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error(data.error);
                return;
            }

            // Загрузка папок
            data.folders.forEach(folder => {
                const folderDiv = document.createElement('div');
                folderDiv.textContent = folder;
                folderDiv.className = 'folder';
                folderDiv.onclick = () => openFolder(folder); // Открываем папку по клику
                folderDiv.oncontextmenu = (event) => showContextMenu(event, folder, 'folder');
                folderList.appendChild(folderDiv);
                // Плавное появление
                setTimeout(() => folderDiv.classList.add('visible'), 0);
            });

            // Загрузка файлов
            data.files.forEach(item => {
                const itemDiv = document.createElement('div');
                itemDiv.className = 'file-item';

                const iconClass = item.isFolder ? 'fas fa-folder' : getFileIcon(item.name);
                const sizeOrFolderLabel = item.isFolder ? 'Папка' : `${formatSize(item.size)}`;
                const dateLabel = new Date(item.uploadDate.replace('Z', '')).toLocaleString();


                itemDiv.innerHTML = `
                    <div><i class="${iconClass}"></i>
                    <span>${item.name}</span></div>
                    <div><span class="file-size">${sizeOrFolderLabel}</span>
                    <span class="file-date">${dateLabel}</span></div>
                `;

                itemDiv.onclick = () => {
                    if (item.isFolder) {
                        openFolder(item.name); // Открыть папку
                    } else {
                        openFile(item.name, currentFolder); // Открыть файл
                    }
                };
                
                itemDiv.oncontextmenu = (event) => showContextMenu(event, item.name, item.isFolder ? 'folder' : 'file');

                fileArea.appendChild(itemDiv);
                // Плавное появление
                setTimeout(() => itemDiv.classList.add(`visible`), 0);
            });
        })
        .catch(console.error);
}

// Форматирование размера файла
function formatSize(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
    return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

// Получение иконки файла по расширению
function getFileIcon(fileName) {
    const extensions = {
        pdf: 'fas fa-file-pdf',
        doc: 'fas fa-file-word',
        docx: 'fas fa-file-word',
        xls: 'fas fa-file-excel',
        xlsx: 'fas fa-file-excel',
        ppt: 'fas fa-file-powerpoint',
        pptx: 'fas fa-file-powerpoint',
        txt: 'fas fa-file-alt',
        jpg: 'fas fa-file-image',
        jpeg: 'fas fa-file-image',
        png: 'fas fa-file-image',
        gif: 'fas fa-file-image',
        zip: 'fas fa-file-archive',
        rar: 'fas fa-file-archive',
    };
    return extensions[fileName.split('.').pop().toLowerCase()] || 'fas fa-file';
}

// Глобальная переменная для хранения текущего контекстного меню
let currentMenu = null;

// Удаление файла или папки
function deleteItem(fileName, type) {
    const folder = currentFolder;

    fetch('/api/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName: fileName, folder: folder })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log(`${fileName} успешно удален.`);
            loadFilesInCurrentFolder();  // Обновляем содержимое папки только после успешного удаления
        } else if (data.error) {
            console.error(`Ошибка: ${data.error}`);
            alert(`Ошибка при удалении: ${data.error}`);
        }
    })
    .catch(error => {
        console.error('Ошибка сети:', error);
        alert('Произошла ошибка при удалении.');
    });
}

// Показ контекстного меню
function showContextMenu(event, name, type) {
    event.preventDefault();

    // Закрыть предыдущее меню, если оно открыто
    if (currentMenu) {
        currentMenu.remove();
    }

    const menu = document.createElement('div');
    menu.className = 'context-menu';

    if (type === 'file') {
        menu.innerHTML = `
            <input type="text" value="${name}" id="renameInput" class="rename-input" />
            <div onclick="copyName('${name}')">Копировать имя</div>
            <div onclick="saveNewName('${name}', 'file'); closeContextMenu()">Изменить имя</div>
            <div onclick="downloadFile('${name}'); closeContextMenu()">Скачать файл</div>
            <div onclick="deleteItem('${name}', 'file'); closeContextMenu()">Удалить файл</div>
        `;
    } else if (type === 'folder') {
        menu.innerHTML = `
            <input type="text" value="${name}" id="renameInput" class="rename-input" />
            <div onclick="copyName('${name}')">Копировать имя</div>
            <div onclick="saveNewName('${name}', 'folder'); closeContextMenu()">Изменить имя</div>
            <div onclick="downloadFolder('${name}'); closeContextMenu()">Скачать папку</div>
            <div onclick="deleteItem('${name}', 'folder'); closeContextMenu()">Удалить папку</div>
        `;
    }

    document.body.appendChild(menu);
    menu.style.top = `${event.pageY}px`;
    menu.style.left = `${event.pageX}px`;

    currentMenu = menu;

    // Добавляем событие клика снаружи, исключая клик по меню и полю ввода
    document.addEventListener('click', function handleClickOutside(event) {
        const inputElement = document.getElementById('renameInput');
        if (!menu.contains(event.target) && event.target !== inputElement) {
            closeContextMenu();
            document.removeEventListener('click', handleClickOutside);
        }
    });
}

// Функция для закрытия контекстного меню
function closeContextMenu() {
    if (currentMenu) {
        currentMenu.remove();
        currentMenu = null; // Сброс переменной
    }
}

// Функция копирования имени
function copyName(name) {
    navigator.clipboard.writeText(name).then(() => {
    }).catch(err => {
        console.error('Ошибка копирования:', err);
    });
}

// Функция сохранения нового имени
function saveNewName(oldName, type) {
    const newName = document.getElementById('renameInput').value;
    
    if (newName && newName !== oldName) {
        const folder = currentFolder; // Текущая папка

        fetch('/api/rename', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                oldName: oldName,
                newName: newName,
                folder: folder,
                type: type  // Передаем тип (файл или папка)
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Ошибка при переименовании: ' + response.statusText);
            } else {
                loadFilesInCurrentFolder();  // Обновление файлов и папок после переименования
            }
        })
        .catch(error => {
            console.error('Ошибка сети:', error);
            alert('Произошла ошибка при сохранении нового имени.');
        });
    }
}

// Функция для скачивания файла
function downloadFile(fileName) {
    const filePath = `${currentFolder}/${fileName}`;
    window.location.href = `/download-file?file=${encodeURIComponent(filePath)}`;
}

// Функция для скачивания папки (требует серверной реализации)
function downloadFolder(folderName) {
    const folderPath = `${currentFolder}/${folderName}`;
    window.location.href = `/download-folder?folder=${encodeURIComponent(folderPath)}`;
}

async function openFile(fileName, folder = '') {
    try {
        const response = await fetch(`/get-file-content?file=${encodeURIComponent(fileName)}&folder=${encodeURIComponent(folder)}`);

        if (response.ok) {
            const data = await response.json();
            const textContentArea = document.getElementById('textContentArea');
            textContentArea.style.display = 'block'; // Отображаем область контента

            // Кнопка "Копировать содержимое"
            const copyButton = document.querySelector('.copy-file-button');
            copyButton.style.display = 'inline';
            const backb = document.querySelector('.back-button');
            backb.style.display = 'none'
            const folderList = document.querySelector('.folder-list');
            folderList.style.display = 'none'
            const fileInput = document.querySelector('.file-input-label');
            
            // Скрываем все элементы в контейнере textContentArea
            const sortingContainer = document.querySelector('.sorting-container');
            const relativePath = document.getElementById('relativePath');
            const folderName = document.getElementById('folderName');
            const fileArea = document.getElementById('fileArea');
            const back_button = document.querySelector('.back-button');

            sortingContainer.style.display = 'none';
            relativePath.style.display = 'none';
            folderName.style.display = 'none';
            fileArea.style.display = 'none';
            back_button.style.display = 'none';

            document.querySelectorAll('h2').forEach(function(h2) {
                if (h2.textContent.trim() === 'Относительные папки') {
                    h2.style.display = 'none';
                }
            });

            copyButton.onclick = () => {
                navigator.clipboard.writeText(textContentArea.innerText)
                    .then(() => {
                        alert('Содержимое скопировано в буфер обмена!');
                    })
                    .catch(err => {
                        console.error('Ошибка копирования:', err);
                    });
            };
            textContentArea.innerHTML = ''; // Очистка области контента перед добавлением нового содержимого

            if (data.type === 'text' || data.type === 'docx') {
                // Заменяем символы новой строки на <br> для сохранения абзацев
                textContentArea.innerHTML += data.content.replace(/\n/g, '<br>'); // Добавляем текстовое содержимое

                // Применяем стили: темный фон и белый текст
                textContentArea.style.padding = '20px'; // Отступы для лучшего отображения

                // Проверяем тип файла для подсветки синтаксиса
                const fileExtension = fileName.split('.').pop(); // Получаем расширение файла
                const codeExtensions = ['js', 'html', 'css', 'py', 'java', 'c', 'cpp']; // Список расширений для подсветки

                if (codeExtensions.includes(fileExtension)) {
                    // Используем <pre> для сохранения отступов и добавляем <code> с языком
                    const language = fileExtension; // Указываем язык на основе расширения
                    textContentArea.innerHTML = `<pre><code class="${language}">${data.content}</code></pre>`; // Оборачиваем содержимое в <pre> и <code>
                    hljs.highlightElement(textContentArea.querySelector('code')); // Автоматическая подсветка для блока
                }
            } else if (data.type === 'image') {
                const imgElement = document.createElement('img');
                const folderPath = data.folder || 'None';  // Если folder пустой или undefined, передаем ''
                imgElement.src = `/user_files_view/${folderPath}/${data.file_name}`;  // Формируем путь к изображению
                imgElement.style.width = '100%';
                imgElement.style.height = 'auto';
                imgElement.style.maxHeight = '90vh';
                imgElement.style.objectFit = 'contain';
                textContentArea.appendChild(imgElement);
            } else if (data.type === 'video') {
                // Используем путь и имя файла, которые пришли с сервера
                const videoElement = document.createElement('video');
                const folderPath = data.folder || 'None';  // Если folder пустой или undefined, передаем ''
                videoElement.src = `/user_files_view${folderPath}/${data.file_name}`;  // Формируем путь к изображению
                videoElement.controls = true;
                videoElement.style.width = '100%';
                videoElement.style.height = 'auto';
                videoElement.style.maxHeight = '90vh';
                videoElement.style.objectFit = 'contain';
                textContentArea.appendChild(videoElement);
            }
            

            // Получаем кнопку "Вернуться"
            const backButton = document.querySelector('.back-file-button');
            backButton.style.display = 'inline'; // Отображаем кнопку "Вернуться"
            // Добавляем обработчик нажатия для кнопки "Вернуться"
            backButton.onclick = () => {
                textContentArea.innerHTML = '';
                textContentArea.style.display = 'none'; // Скрываем область контента
                // Перезагрузка файлов в текущей папке
                document.querySelectorAll('h2').forEach(function(h2) {
                    if (h2.textContent.trim() === 'Относительные папки') {
                        h2.style.display = 'inline-block';
                    }
                });
                folderList.style.display = 'block';
                backButton.style.display = 'none'; // Скрываем кнопку "Вернуться"
                copyButton.style.display = 'none';

                back_button.style.display = 'flex';
                sortingContainer.style.display = 'flex';
                relativePath.style.display = 'initial';
                folderName.style.display = 'flex';
                fileArea.style.display = 'initial';
                loadFilesInCurrentFolder();
            };

        } else {
            console.error(`Ошибка: ${response.status} - Файл не найден`);
        }
    } catch (error) {
        console.error(`Ошибка при открытии файла: ${error}`);
    }
}

let currentSortOrder = 'asc'; // По умолчанию восходящий порядок

// Переключение порядка сортировки
function toggleSortOrder() {
    const sortOrderButton = document.getElementById('sortOrderButton');
    currentSortOrder = currentSortOrder === 'asc' ? 'desc' : 'asc';
    
    // Обновляем текст кнопки в зависимости от направления сортировки
    sortOrderButton.innerHTML = currentSortOrder === 'asc'
        ? 'Восходящий <i class="fas fa-arrow-up icon"></i>'
        : 'Нисходящий <i class="fas fa-arrow-down icon"></i>';

    sortFiles(); // Обновляем сортировку после изменения направления
}

// Обработка изменения сортировки
function sortFiles() {
    const filesData = getFileAreaData(); // Получаем данные файлов из fileArea

    // Проверяем, есть ли файлы для сортировки
    if (filesData.length === 0) {
        console.error('Файлы не найдены для сортировки');
        return;
    }

    const selectedSortCriteria = document.getElementById("sortOptions").value; // Получаем выбранный критерий
    const sortedFiles = sortFilesByCriteria(filesData, selectedSortCriteria, currentSortOrder); // Сортируем файлы
    renderFiles(sortedFiles); // Отображаем отсортированные файлы
}

// Получаем данные файлов из fileArea
function getFileAreaData() {
    return Array.from(document.querySelectorAll('#fileArea .file-item')).map(fileElement => {
        const fileName = fileElement.querySelector('span').textContent;
        const fileSizeText = fileElement.querySelector('.file-size').textContent;
        const fileDateText = fileElement.querySelector('.file-date').textContent;

        const formattedDate = parseDate(fileDateText);
        const fileSize = convertSizeToBytes(fileSizeText);

        return {
            name: fileName,
            size: fileSize,
            date: formattedDate,
            type: fileName.split('.').pop(),
            element: fileElement
        };
    });
}

// Преобразование размера файла в байты
function convertSizeToBytes(sizeText) {
    const size = parseFloat(sizeText);
    const unit = sizeText.slice(-2).toUpperCase();

    switch (unit) {
        case 'MB': return size * 1024 * 1024;
        case 'KB': return size * 1024;
        case 'GB': return size * 1024 * 1024 * 1024;
        default: return size; // Без единиц — байты
    }
}

// Преобразование текста даты в объект Date
function parseDate(dateText) {
    const [datePart, timePart] = dateText.split(', ');
    const [day, month, year] = datePart.split('.');
    return new Date(`${year}-${month}-${day}T${timePart}`);
}

// Сортировка файлов по критерию
function sortFilesByCriteria(filesData, criterion, sortOrder) {
    return filesData.sort((a, b) => {
        const comparison = (criterion === 'name' || criterion === 'type')
            ? a[criterion].localeCompare(b[criterion])
            : a[criterion] - b[criterion];

        return sortOrder === 'asc' ? comparison : -comparison;
    });
}

// Отображение файлов
function renderFiles(sortedFiles) {
    const fileArea = document.getElementById('fileArea');
    fileArea.innerHTML = '';  // Очищаем перед рендерингом

    sortedFiles.forEach(file => fileArea.appendChild(file.element)); // Добавляем отсортированные файлы
}

// Поиск файлов
function searchFiles() {
    const searchQuery = document.getElementById('file-search').value.toLowerCase();
    document.querySelectorAll('.file-item').forEach(file => {
        const fileName = file.querySelector('span').textContent.toLowerCase();
        file.style.display = fileName.includes(searchQuery) ? '' : 'none'; // Показываем или скрываем в зависимости от запроса
    });
}

// Начальная загрузка файлов в главной папке
loadFilesInCurrentFolder();
