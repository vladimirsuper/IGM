// Функция для включения режима редактирования
function enableEditing() {
    const inputs = document.querySelectorAll('#user-details-form input');
    inputs.forEach(input => input.removeAttribute('readonly'));

    // Показать кнопку "Сохранить"
    document.getElementById('save-button').style.display = 'block';
    // Скрыть кнопку "Изменить"
    document.getElementById('edit-button').style.display = 'none';
}
// Функция для сохранения информации пользователя
function saveUserInfo() {
    let formData = new FormData(document.getElementById('user-details-form'));

    // Блокируем кнопку, чтобы избежать множественного нажатия
    const saveButton = document.getElementById('save-button');
    saveButton.disabled = true;

    fetch('/update_info', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Обновляем отображаемое имя пользователя
            document.getElementById('username').textContent = data.username;
            
            // Блокируем поля после сохранения
            const inputs = document.querySelectorAll('#user-details-form input');
            inputs.forEach(input => input.setAttribute('readonly', true));

            // Скрываем кнопку "Сохранить" и показываем "Изменить"
            saveButton.style.display = 'none';
            document.getElementById('edit-button').style.display = 'block';
        } else {
            alert('Ошибка обновления информации: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Ошибка запроса:', error);
        alert('Ошибка запроса: ' + error);
    })
    .finally(() => {
        // Разблокируем кнопку после завершения запроса
        saveButton.disabled = false;
    });
}

// Функция для загрузки и обновления фото
function uploadPhoto(input) {
    const file = input.files[0];
    if (!file) return;

    // Немедленно обновляем изображение на экране
    const reader = new FileReader();
    reader.onload = function (e) {
        document.getElementById('userIcon').src = e.target.result;
    };
    reader.readAsDataURL(file);  // Загружаем локальный файл как URL

    const formData = new FormData();
    formData.append('photo', file);

    // Отправляем фото на сервер
    fetch('/upload_photo', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {} else {
            alert('Ошибка при загрузке фото: ' + data.message);
        }
    })
    .catch(error => console.error('Ошибка загрузки фото:', error));
}

// Функция для показа/скрытия пароля
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleButton = document.getElementById('toggle-password');

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleButton.textContent = 'Скрыть';
    } else {
        passwordInput.type = 'password';
        toggleButton.textContent = 'Показать';
    }
}

async function fetchUserData() {
    try {
        const response = await fetch('/api/user');
        if (response.ok) {
            const userData = await response.json();
            document.getElementById("username").textContent = userData.username;
            
            // Устанавливаем изображение с помощью Base64-кода
            const userIcon = document.getElementById("userIcon");
            userIcon.src = "data:image/png;base64," + userData.icon_base64;
        } else {
            console.error('Ошибка при получении данных пользователя');
        }
    } catch (error) {
        console.error('Ошибка:', error);
    }
}

document.addEventListener("DOMContentLoaded", () => {
    fetchUserData();
});

// Функция для показа/скрытия email
function toggleEmail() {
    const emailInput = document.getElementById('email');
    const toggleButton = document.getElementById('toggle-email');

    if (emailInput.type === 'email') {
        emailInput.type = 'text';
        toggleButton.textContent = 'Скрыть';
    } else {
        emailInput.type = 'email';
        toggleButton.textContent = 'Показать';
    }
}