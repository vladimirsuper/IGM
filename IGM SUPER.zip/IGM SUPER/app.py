import os
import secrets
import shutil
import asyncio
import base64
from authlib.integrations.flask_client import OAuth
from flask import Flask, request, jsonify, session, redirect, render_template, url_for, send_from_directory, send_file
import tempfile
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_cors import CORS
from datetime import datetime, timezone
from config import INFO_ABOUT_USERS, DATA, users_folders_all
import re
import mimetypes
import docx2txt
from urllib.parse import unquote

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SECRET_KEY'] = 'jafafBLV>UAWKfbjalfwFBA>FWl'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

oauth = OAuth(app)

# Настройки для GitHub OAuth
github = oauth.register(
    name='github',
    client_id='Ov23lipyvGWccHbsI8Es',
    client_secret='02c8f9d9668a5857c71a26801cde8c8724ad70ee',
    access_token_url='https://github.com/login/oauth/access_token',
    authorize_url='https://github.com/login/oauth/authorize',
    client_kwargs={'scope': 'user:email'},
    redirect_uri='http://127.0.0.1:5000/auth/callback/github'
)

google = oauth.register(
    name='google',
    client_id='830363002162-upum33h6untbjq9binl3n8gtf740t8me.apps.googleusercontent.com',
    client_secret='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',
    access_token_url='https://accounts.google.com/o/oauth2/token',
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    userinfo_endpoint='https://openidconnect.googleapis.com/v1/userinfo',
    client_kwargs = {'scope': 'openid email profile','issuer': 'https://accounts.google.com'},
    jwks_uri = "https://www.googleapis.com/oauth2/v3/certs"
)

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
CORS(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(80), unique=True, nullable=False)
    username = db.Column(db.String(80), nullable=False)
    password = db.Column(db.String(120), nullable=False)
    folder_name = db.Column(db.String(120), unique=True, nullable=False)  # Поле для имени папки

async def new_users_db(email, hashed_password, folder_name):
    new_user = User(username="Пользователь", email=email, password=hashed_password, folder_name=folder_name)
    db.session.add(new_user)
    db.session.commit()
    # Создание директорий для нового пользователя
    await create_user_folders(folder_name)
    session['user_folder'] = new_user.folder_name
    session['email'] = new_user.email  
    session['username'] = new_user.username
    
# Функция для создания папок пользователя
async def create_user_folders(folder_name):
    os.makedirs(os.path.join(users_folders_all, folder_name, DATA), exist_ok=True)
    os.makedirs(os.path.join(users_folders_all, folder_name, INFO_ABOUT_USERS), exist_ok=True)
    
async def gbfolder(folder=''):
    if 'user_folder' not in session:
        return jsonify({'error': 'Пользователь не авторизован'}), 403
    return os.path.join(users_folders_all, session['user_folder'], DATA, folder)

def allowed_file(filename): # Проверка разрешенного формата для аватарки пользователя
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg', 'gif'}

@app.route('/upload_photo', methods=['POST'])
def upload_photo():
    file = request.files.get('photo')
    if not file or not allowed_file(file.filename):
        return jsonify({'success': False, 'message': 'Ошибка при загрузке файла'}), 400

    user_folder = os.path.join(users_folders_all, session['user_folder'], INFO_ABOUT_USERS)
    file_path = os.path.join(user_folder, 'photo.png')
    file.save(file_path)
    return jsonify({'success': True, 'new_avatar_url': file_path}), 200

@app.route('/info')
def info():
    email = session['email']
    user = User.query.filter_by(email=email).first()
    if user:
        return render_template('info.html', username=user.username, email=user.email, password=user.password)
    else:
        return redirect(url_for('login'))  # Перенаправление на страницу логина, если данных нет

@app.route('/update_info', methods=['POST']) # Получаем пользователя из базы данных
def update_info():
    user = User.query.filter_by(email=session['email']).first()
    if user:
        user.username = request.form['username']
        new_email = request.form['email']
        new_password = request.form['password']
        if new_password and new_password != user.password: # Если пароль изменился, то изменяем его
            user.password = new_password
            session['password'] = new_password
        session['username'] = user.username
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', new_email):
            return jsonify({'error': 'Введите корректный адрес электронной почты'}), 400

        if User.query.filter_by(email=new_email).first() and user.email != new_email:
            return jsonify({'error': 'Почта уже находится в системе'}), 400
        
        user.email = new_email
        session['email'] = new_email
        try:
            db.session.commit()
            return jsonify({'success': True, 'username': session['username']})
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': f'Ошибка обновления информации: {str(e)}'})
    else:
        return jsonify({'success': False, 'message': 'Пользователь не найден'}), 404
    
@app.route('/login/<provider>')
def login_provider(provider):
    if provider == 'google':
        redirect_uri = url_for('auth_callback', provider='google', _external=True)
        return google.authorize_redirect(redirect_uri)
    elif provider == 'github':
        redirect_uri = url_for('auth_callback', provider='github', _external=True)
        return github.authorize_redirect(redirect_uri)
    else:
        return "Unsupported provider", 400

@app.route('/auth/callback/<provider>')
def auth_callback(provider):
    if provider == 'google':
        token = google.authorize_access_token()
        if not token:
            return "Ошибка получения токена Google", 400
        user_info = google.get('https://openidconnect.googleapis.com/v1/userinfo').json()
        if 'error' in user_info:
            return f"Ошибка получения информации о пользователе: {user_info['error']}", 400

        email = user_info.get('email')

    elif provider == 'github':
        token = github.authorize_access_token()
        if not token:
            return "Ошибка получения токена GitHub", 400
        email_info = github.get('https://api.github.com/user/emails').json()
        email = next((email['email'] for email in email_info if email['primary']), None)
    # Проверяем, существует ли пользователь в базе данных
    user = User.query.filter_by(email=email).first()
    if user:
        session['user_folder'] = user.folder_name
        session['email'] = user.email  # Сохранение email в сессии
        session['username'] = user.username 
        return redirect('/dashboard')
    # Если пользователя нет, создаем нового
    hashed_password = bcrypt.generate_password_hash(secrets.token_hex(10)).decode('utf-8')
    folder_name = secrets.token_hex(10)

    asyncio.run(new_users_db(email, hashed_password, folder_name))
    return redirect('/dashboard')

def encode_image_to_base64(image_path):
    """Функция для кодирования изображения в Base64."""
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

@app.route('/api/user')
def get_user_data():
    if 'user_folder' not in session:
        return render_template('login.html')

    user = User.query.filter_by(email=session['email']).first()
    if not user:
        return render_template('login.html')

    user_icon_path = os.path.join(os.path.join(users_folders_all, session['user_folder'], INFO_ABOUT_USERS), 'photo.png')

    # Используем изображение по умолчанию, если иконка пользователя отсутствует
    icon_path = user_icon_path if os.path.exists(user_icon_path) else os.path.join(app.static_folder, 'images', 'default-user-icon.png')
    
    user_icon_base64 = encode_image_to_base64(icon_path)

    return jsonify({
        'username': session['username'],
        'icon_base64': user_icon_base64
    }), 200

# Маршрут для отправки иконки пользователя
@app.route('/user_icon/<user_folder>')
def user_icon(user_folder):
    # Путь к иконке пользователя
    icon_path = os.path.join(users_folders_all, user_folder, INFO_ABOUT_USERS)
    return send_from_directory(icon_path, 'photo.png')

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()  # Используйте это, если отправляете JSON
    email = data.get('email')
    password = data.get('password')
    if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
        return jsonify({'error': 'Введите корректный адрес электронной почты'}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Почта уже находится в системе'}), 400

    asyncio.run(new_users_db(email, password, secrets.token_hex(10)))
    return jsonify({'message': 'Регистрация успешна', 'redirect_url': '/dashboard'}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data['email']
    password = data['password']

    user = User.query.filter_by(email=email).first()
    if user and user.password == password:
        session['user_folder'] = user.folder_name
        session['email'] = user.email  # Сохранение email в сессии
        session['username'] = user.username  # Сохранение email в сессии
        return jsonify({'message': 'Вход успешен', 'folder_name': user.folder_name}), 200

    return jsonify({'error': 'Некорректная почта или пароль'}), 401

# Выход пользователя
@app.route('/logout', methods=['POST'])
def logout():
    session.pop('user_folder', None)
    session.pop('username', None)
    session.pop('email', None)
    session.pop('password', None)
    return jsonify({'message': 'Выход успешен'}), 200

@app.route('/')
def login_another_method():
    if 'user_folder' in session:
        return redirect('/dashboard')  # Если пользователь уже вошел, перенаправляем на дашборд
    return render_template('login.html')

# Страница после входа
@app.route('/dashboard')
def dashboard():
    if 'user_folder' in session:
        return render_template('dashboard.html')  # Страница после входа
    return redirect('/')  # Перенаправление на страницу входа

@app.route('/upload', methods=['POST'])
def upload_files_and_folders():
    folder = request.args.get('folder', '')  # Получаем папку из параметров
    user_folder = asyncio.run(gbfolder(folder))
    files = request.files.getlist('files')
    
    for file in files:
        encoded_filename = file.filename
        decoded_filename = unquote(encoded_filename)
        save_path = os.path.join(user_folder, decoded_filename)
        
        # Проверяем, содержит ли путь вложенные папки (например, для папок)
        if not os.path.exists(os.path.dirname(save_path)):
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
        
        file.save(save_path)  # Сохраняем файл или создаем папку с файлами
    
    return jsonify({'error': ''})

@app.route('/create-folder', methods=['POST'])
def create_folder():
    data = request.json
    folder_name = data['folderName']
    current_path = data.get('currentPath', '')
    user_folder = asyncio.run(gbfolder())
    target_path = os.path.join(user_folder, current_path, folder_name)
    if not os.path.exists(target_path):
        try:
            os.makedirs(target_path)
        except Exception as e:
            return jsonify({'error': f'Ошибка при создании папки: {str(e)}'}), 500

    return jsonify({'error': 'Папка уже существует'}), 400

@app.route('/files', methods=['GET'])
def get_files():
    max_length = 30
    folder = request.args.get('folder', '')  # Получаем папку из параметров запроса
    user_folder = asyncio.run(gbfolder(folder))  # Путь к директории пользователя

    if not os.path.exists(user_folder) or not os.path.isdir(user_folder):
        return jsonify({"error": "Папка не существует"}), 404

    try:
        items = os.listdir(user_folder)
        
        files_data = [
            {
                'name': item[:max_length - 3] + '...' if len(item) > max_length else item,
                'size': os.path.getsize(os.path.join(user_folder, item)) if not os.path.isdir(os.path.join(user_folder, item)) else 0,
                'uploadDate': datetime.fromtimestamp(os.path.getmtime(os.path.join(user_folder, item)), timezone.utc).isoformat(timespec='seconds') + 'Z',
                'isFolder': os.path.isdir(os.path.join(user_folder, item))
            }
            for item in items  # Используем только уникальные элементы
        ]
        
        # Только папки, без дубликатов
        folders = [item for item in items if os.path.isdir(os.path.join(user_folder, item))]
    
    except Exception as e:
        return jsonify({"error": f"Ошибка при получении содержимого папки: {str(e)}"}), 500

    return jsonify({"folders": folders, "files": files_data}), 200

@app.route('/download-file', methods=['GET'])
def download_file():
    file_path = asyncio.run(gbfolder()) + request.args.get('file')
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        return "Файл не найден", 404

@app.route('/download-folder', methods=['GET'])
def download_folder():
    folder_name = request.args.get('folder')
    folder_path = asyncio.run(gbfolder()) + folder_name
    
    # Проверяем, существует ли папка
    if os.path.exists(folder_path) and os.path.isdir(folder_path):
        try:
            # Создаем временный файл для архива
            with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as temp_archive:
                archive_name = temp_archive.name

            # Архивируем папку
            shutil.make_archive(archive_name[:-4], 'zip', folder_path)

            # Отправляем файл для скачивания
            response = send_file(archive_name, as_attachment=True)

            # Удаляем архив после отправки
            response.call_on_close(lambda: os.remove(archive_name))

            return response

        except Exception as e:
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": "Папка не найдена"}), 404

@app.route('/check-folder')
def check_folder():
    folder = request.args.get('folder')
    user_folder = asyncio.run(gbfolder(folder))
    if os.path.exists(user_folder) and os.path.isdir(user_folder):
        return '', 200  # Папка существует
    else:
        return '', 404  # Папка не найдена
    
@app.route('/get-file-content', methods=['GET'])
def get_file_content():
    folder = request.args.get('folder', '')
    file_name = request.args.get('file', '')
    
    # Полный путь к файлу
    file_path = asyncio.run(gbfolder(os.path.join(folder, file_name)))
    
    # Проверка существования файла
    if os.path.exists(file_path) and os.path.isfile(file_path):
        try:
            # Определяем тип файла
            mime_type, _ = mimetypes.guess_type(file_path)

            if mime_type and mime_type.startswith('text'):
                # Чтение текстовых файлов
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                return jsonify({"content": content, "type": "text"})
            elif mime_type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
                # Чтение содержимого файлов DOCX
                content = docx2txt.process(file_path)
                return jsonify({"content": content, "type": "docx"})
            elif mime_type and mime_type.startswith('image'):
                return jsonify({
                    "content": base64.b64encode(open(file_path, 'rb').read()).decode('utf-8'),
                    "type": "image",
                    "file_name": file_name,
                    "folder": folder
                })
            elif mime_type and mime_type.startswith('video'):
                # Для видео возвращаем только путь
                return jsonify({
                    "type": "video",
                    "file_name": file_name,
                    "folder": folder
                })
            else:
                return jsonify({"error": "Неподдерживаемый тип файла"}), 415
        except Exception as e:
            return jsonify({"error": f"Ошибка при чтении файла: {str(e)}"}), 500
    else:
        return jsonify({"error": "Файл не найден"}), 404

@app.route('/user_files_view/<path:folder>/<file_name>', methods=['GET'])
def get_user_files(folder, file_name):
    # Используем асинхронную функцию для получения пути
    folder_path = asyncio.run(gbfolder('' if folder == 'None' else folder))
    
    # Путь к видео пользователя
    media_path = os.path.join(folder_path, file_name)
    print(media_path)
    return send_from_directory(os.path.dirname(media_path), os.path.basename(media_path))

# Переименование файлов или папок
@app.route('/api/rename', methods=['POST'])
def rename_file_or_folder():
    data = request.get_json()
    old_name = data.get('oldName')
    new_name = data.get('newName')
    folder = data.get('folder')  # Путь к папке

    user_folder = asyncio.run(gbfolder(folder))
    old_path = os.path.join(user_folder, old_name)
    new_path = os.path.join(user_folder, new_name)

    # Проверка существования старого файла/папки
    if not os.path.exists(old_path):
        return jsonify({"error": "Файл или папка не найдены"}), 404

    # Проверка на существование нового имени
    if os.path.exists(new_path):
        return jsonify({"error": "Файл или папка с таким именем уже существует"}), 400

    # Попытка переименовать
    try:
        os.rename(old_path, new_path)
    except Exception as e:
        print(f"Ошибка при переименовании: {e}")
        return jsonify({"error": "Ошибка при переименовании"}), 500

    # Возврат успешного ответа
    return jsonify({"success": True, "newName": new_name}), 200


# Удаление файла или папки
@app.route('/api/delete', methods=['POST'])
def delete_file_or_folder():
    data = request.get_json()
    file_name = data.get('fileName')
    folder = data.get('folder')  # Путь к папк

    # Получаем путь к папке пользователя
    user_folder = asyncio.run(gbfolder(folder))
    
    # Безопасное соединение путей
    file_path = os.path.join(user_folder, file_name)
    file_path = os.path.normpath(file_path)  # Нормализация пути (избежание обхода директорий)

    if not os.path.exists(file_path):
        return jsonify({"error": "Файл или папка не найдены"}), 404

    try:
        if os.path.isdir(file_path):
            shutil.rmtree(file_path)  # Удаляем папку и её содержимое
        else:
            os.remove(file_path)  # Удаляем файл
        
        return jsonify({"success": True}), 200
    except Exception as e:
        print(f"Ошибка при удалении: {e}")
        return jsonify({"error": "Ошибка при удалении"}), 500

if __name__ == '__main__':
    # Создание таблиц, если они не существуют
    if not os.path.exists('instance/users.db'):
        with app.app_context():
            db.create_all()  
    app.run(debug=True)
